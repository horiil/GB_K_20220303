package com.koreait.jpaitem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaitemApplicationTests {

	@Test
	void contextLoads() {
	}

}
