package com.koreait.Springtest3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springtest3Application {

	public static void main(String[] args) {
		SpringApplication.run(Springtest3Application.class, args);
	}

}
