package com.koreait.dao;

import com.koreait.beans.UserBean;

public class UserDao {
	// DB Connection
	
	// 회원가입
	public boolean join ( UserBean bean ) {
		// DB처리
		// ...
		
		
		
		
		return true;
	}
	
	
}
